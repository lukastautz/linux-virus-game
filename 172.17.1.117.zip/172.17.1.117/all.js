/*
siteFactoryCSS <https://github.com/siteFactorySource/siteFactoryCSS>
Copyright (C) 2022 Lukas Tautz

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

You can use siteFactoryCSS for free in your projects, you can also modify the siteFactoryCSS files BUT YOU ARE NOT ALLOWED TO DELETE THIS COMMENT!
*/
var Modal=function(e,t){this.isRemoved=!1;var o='<div class="overlay" id="modal-overlay-id"></div><div class="wrapper"><div class="header">'+e+'<span class="close">&times;</span></div><div class="inner">'+t+"</div></div>";this.modal=document.createElement("div"),this.modal.classList.add("modal"),this.modal.id="modal",this.modal.innerHTML=o,document.body.appendChild(this.modal);var n=this.modal.getElementsByClassName("close")[0],d=this.modal;n.addEventListener("click",function(){d.classList.remove("active"),null!=document.querySelector("nav.nav-default")&&document.querySelector("nav.nav-default").classList.remove("hidden"),this.isRemoved=!0,document.body.removeChild(d)}),window.addEventListener("click",this.windowIsClicked)};Modal.prototype.open=function(){1==this.isRemoved&&document.body.appendChild(this.modal),this.modal.classList.add("active"),null!=document.querySelector("nav.nav-default")&&document.querySelector("nav.nav-default").classList.add("hidden")},Modal.prototype.close=function(){this.modal.classList.remove("active"),null!=document.querySelector("nav.nav-default")&&document.querySelector("nav.nav-default").classList.remove("hidden"),this.isRemoved=!0,document.body.removeChild(this.modal)},Modal.prototype.windowIsClicked=function(e){null!=this.modal&&null!=this.modal&&this.modal.classList.contains("active")&&"modal-overlay-id"==e.target.id&&(this.modal.classList.remove("active"),null!=document.querySelector("nav.nav-default")&&document.querySelector("nav.nav-default").classList.remove("hidden"),this.isRemoved=!0,document.body.removeChild(this.modal))},Modal.prototype.changeTitle=function(e){this.modal.getElementsByClassName("header")[0].innerHTML=e+'<span class="close">&times;</span>'},Modal.prototype.changeContent=function(e){this.modal.getElementsByClassName("inner")[0].innerHTML=e},Modal.prototype.changeHTML=function(e){this.modal.getElementsByClassName("inner")[0].innerHTML=e};var Toast=function(e,t,o){this.toast=document.createElement("div"),this.toast.innerHTML=e,1!=o&&(o=""),1==o&&(o=" danger"),this.toast.className="toast"+o,this.toast.id="toast",document.body.appendChild(this.toast);var n=this.toast;n.addEventListener("mouseover",function(){n.addEventListener("mouseleave",function(){document.body.removeChild(n)})}),null!=t&&null!=t&&n.addEventListener("click",t),setTimeout(function(){null!=document.getElementById("toast")&&document.body.removeChild(n)},1e4)};if(Toast.prototype.hide=function(){document.body.removeChild(this.toast)},Toast.prototype.remove=function(){document.body.removeChild(this.toast)},!$)function $(e){if("string"==typeof e){var t=document.querySelectorAll(e);return 1==t.length?t[0]:t}return e}if(!$$)function $$(e){return document.getElementById(e)}if(!byId)function byId(e){return document.getElementById(e)}String.prototype.replaceAll||(String.prototype.replaceAll=function(e,t){return"[object regexp]"===Object.prototype.toString.call(e).toLowerCase()?this.replace(e,t):this.replace(new RegExp(e,"g"),t)}),HTMLElement.prototype.on=function(e,t){return this.addEventListener(e,t)};
/* sitefactorycss.min.js */