<?php
ini_set('display_errors', 'on');
$body = '';
if(!function_exists('http_response_code')){function http_response_code($code=null){if($code!=null){$code=intval($code);switch($code){case 100:$text='Continue';break;case 101:$text='Switching Protocols';break;case 200:$text='OK';break;case 201:$text='Created';break;case 202:$text='Accepted';break;case 203:$text='Non-Authoritative Information';break;case 204:$text='No Content';break;case 205:$text='Reset Content';break;case 206:$text='Partial Content';break;case 300:$text='Multiple Choices';break;case 301:$text='Moved Permanently';break;case 302:$text='Moved Temporarily';break;case 303:$text='See Other';break;case 304:$text='Not Modified';break;case 305:$text='Use Proxy';break;case 400:$text='Bad Request';break;case 401:$text='Unauthorized';break;case 402:$text='Payment Required';break;case 403:$text='Forbidden';break;case 404:$text='Not Found';break;case 405:$text='Method Not Allowed';break;case 406:$text='Not Acceptable';break;case 407:$text='Proxy Authentication Required';break;case 408:$text='Request Time-out';break;case 409:$text='Conflict';break;case 410:$text='Gone';break;case 411:$text='Length Required';break;case 412:$text='Precondition Failed';break;case 413:$text='Request Entity Too Large';break;case 414:$text='Request-URI Too Large';break;case 415:$text='Unsupported Media Type';break;case 500:$text='Internal Server Error';break;case 501:$text='Not Implemented';break;case 502:$text='Bad Gateway';break;case 503:$text='Service Unavailable';break;case 504:$text='Gateway Time-out';break;case 505:$text='HTTP Version not supported';break;default:$code=500;$text='Internal Server Error';break;}if(isset($_SERVER['SERVER_PROTOCOL'])){$protocol=$_SERVER['SERVER_PROTOCOL'];}else{$protocol='HTTP/1.0';}header($protocol.' '.$code.' '.$text);$return=true;}else{if(isset($GLOBALS['http_response_code'])){$return=$GLOBALS['http_response_code'];}else{$return=200;}}return $return;}}class WebServer{private int $statusCode=200;private string $contentType='text/html; charset=UTF-8';public function __construct(int $statusCode=200){ob_start();$this->statusCode=$statusCode;header_remove('Content-Type');header_remove('content-type');}public function set_status_code(int $statusCode){$this->statusCode=$statusCode;}public function flush(){http_response_code($this->statusCode);header('Content-Type:'.$this->contentType);ob_end_flush();}public function redirect_to(string $url){ob_end_clean();header('Location: '.$url);}public function set_content_type(string $contentType='HTML'){switch(strtolower($contentType)){case 'html':$contentType='text/html; charset=UTF-8';break;case 'javascript':$contentType='text/javascript; charset=UTF-8';break;case 'js':$contentType='text/javascript; charset=UTF-8';break;case 'css':$contentType='text/javascript; charset=UTF-8';break;case 'txt':$contentType='text/plain; charset=UTF-8';break;case 'text':$contentType='text/plain; charset=UTF-8';break;case 'zip':$contentType='application/zip; charset=UTF-8';break;case 'pdf':$contentType='application/pdf; charset=UTF-8';break;case 'xml':$contentType='text/xml; charset=UTF-8';break;case 'default':$contentType='text/html; charset=UTF-8';break;case 'json':$contentType='application/json; charset=UTF-8';break;case 'mp4':$contentType='video/mp4; charset=UTF-8';break;case 'mp3':$contentType='audio/mpeg; charset=UTF-8';break;case 'wav':$contentType='audio/wav; charset=UTF-8';break;case 'bmp':$contentType='image/bmp; charset=UTF-8';break;case 'gif':$contentType='image/gif; charset=UTF-8';break;case 'ief':$contentType='image/ief; charset=UTF-8';break;case 'jpg':$contentType='image/jpeg; charset=UTF-8';break;case 'png':$contentType='image/png; charset=UTF-8';break;case 'jpeg':$contentType='image/jpeg; charset=UTF-8';break;case 'svg':$contentType='image/svg+xml; charset=UTF-8';break;case 'tiff':$contentType='image/tiff;audio/wav; charset=UTF-8';break;case 'ico':$contentType='image/x-icon; charset=UTF-8';break;case 'icon':$contentType='image/x-icon; charset=UTF-8';break;case 'ogg':$contentType='video/ogg; charset=UTF-8';break;case 'quicktime':$contentType='video/quicktime; charset=UTF-8';break;case 'webm':$contentType='video/webm; charset=UTF-8';break;case 'avi':$contentType='video/x-msvideo; charset=UTF-8';break;default:$contentType=$contentType;}$this->contentType=$contentType;}public function get_headers(){return headers_list();}public function header(string $name,string $value,string $splitSymbol=': '){return header($name.$splitSymbol.$value);}public function raw_header(string $rawHeader){return header($rawHeader);}public function remove_header(string $header){header_remove($header);}public function no_cache(){header_remove('Cache-Control');header_remove('cache-control');header_remove('expires');header_remove('Expires');header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');}public function set_cache(int $cacheSeconds){header_remove('Cache-Control');header_remove('cache-control');return header('Cache-Control: max-age='.strval($cacheSeconds));}}class Random{private function randomInt(int $min,int $max){if(function_exists('mt_rand')){return mt_rand($min,$max);}else{return rand($min,$max);}}private function random_int(int $min,int $max){if(function_exists('mt_rand')){return mt_rand($min,$max);}else{return rand($min,$max);}}public function int(int $min,int $max){return $this->randomInt($min,$max);}public function string(int $length=10,string $alphabet='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'){$alphabetLength=strlen($alphabet);$return='';for($step=0;$step<=$length-1;$step++){$return.=$alphabet[$this->randomInt(0,$alphabetLength-1)];}return $return;}}class Session{private?string $id=null;private int $minLength=50;public string $cookieName='session';public int $sessionIdLength=150;public function __construct(string $cookieName='session',int $sessionIdLength=150){$this->cookieName=$cookieName;if($sessionIdLength>$this->minLength){$this->sessionIdLength=$sessionIdLength;}else{$this->sessionIdLength=$this->minLength;}$newCookie=false;session_name($this->cookieName);session_set_cookie_params(['httponly'=>true,'secure'=>false,'samesite'=>'Strict']);session_set_cookie_params(time()+60*60*24*366,'/');if(!isset($_COOKIE[$this->cookieName])){$this->id=$this->getNewId();session_id($this->id);session_start();$_SESSION['sessionCookieCheckAge']=time();$newCookie=true;}else{session_start();if(!isset($_SESSION['sessionCookieCheckAge'])){session_destroy();session_name($this->cookieName);session_set_cookie_params(['httponly'=>true,'secure'=>false,'samesite'=>'Strict']);session_set_cookie_params(time()+60*60*24*366,'/');$this->id=$this->getNewId();session_id($this->id);session_start();$_SESSION['sessionCookieCheckAge']=time();$newCookie=true;}}if($newCookie==false){$this->id=$_COOKIE[$this->cookieName];if($this->getAge()>60*24){$this->newId();}}}public function getAge(){return(time()-$_SESSION['sessionCookieCheckAge'])/60;}public function destroy(){session_destroy();}public function getId(){return $this->id;}public function newId(){$oldSessionData=$_SESSION;$this->destroy();session_name($this->cookieName);session_set_cookie_params(['httponly'=>true,'secure'=>false,'samesite'=>'Strict']);session_set_cookie_params(time()+60*60*24*366,'/');$this->id=$this->getNewId();session_id($this->id);session_start();$_SESSION=$oldSessionData;$_SESSION['sessionCookieCheckAge']=time();}private function getNewId(){$maxLength=$this->sessionIdLength;$Random=new Random();$RandomString=$Random->string($maxLength,'abcdefghijklmnopqrstuvwxyz1234567890-');if(function_exists('session_create_id')){$collisionFreeId=session_create_id();$collisionFreeId=strtolower($collisionFreeId);$collisionFreeId=str_replace(',','',$collisionFreeId);}else{$collisionFreeId='';}$id=$collisionFreeId.$RandomString;return substr($id,0,$maxLength);}public function get_age(){return $this->getAge();}public function get_id(){return $this->id;}public function new_id(){return $this->newId();}private function get_new_id(){return $this->getNewId();}public function close(){session_write_close();}}if(!function_exists('sha512')){function sha512(string $password){return hash('sha512',$password);}}if(!function_exists('sha_512')){function sha_512(string $password){return hash('sha512',$password);}}
if (!file_exists('settings.smngr'))
{
    file_put_contents('settings.smngr', '{"users":{"root":"' . sha512('root') . '"},"color":"black","corner":"false","lang":"en"}');
    $_SERVER['mngr_users'] = ['root' => sha512('root')];
    $_SERVER['mngr_color'] = 'black';
    $_SERVER['mngr_lang'] = 'en';
    $_SERVER['mngr_corner'] = '';
    $_SERVER['mngr_corner_b'] = '';
}
else
{
    $json = json_decode(file_get_contents('settings.smngr'), true);
    $_SERVER['mngr_users'] = $json['users'];
    $_SERVER['mngr_color'] = $json['color'];
    $_SERVER['mngr_lang'] = $json['lang'];
    if ($json['corner'] == "true")
    {
        $_SERVER['mngr_corner'] = ' corner';
        $_SERVER['mngr_corner_b'] = 'corner';
    }
    else
    {
        $_SERVER['mngr_corner'] = '';
        $_SERVER['mngr_corner_b'] = '';
    }
}
function tr(string $id)
{
   $lang_array = [
       'en' => [
           'login' => 'Login',
           'username' => 'Username',
           'password' => 'Password',
           'error_false_data' => 'An error is occured: Data is invalid!',
           'error' => 'Error',
           'logout' => 'Logout'
       ],
       'de' => [
           'login' => 'Anmelden',
           'username' => 'Benutzername',
           'password' => 'Passwort',
           'error_false_data' => 'Ein Fehler ist aufgetreten: Falsche Daten!',
           'error' => 'Fehler',
           'logout' => 'Abmelden',
           'sites' => 'Seiten',
           'users' => 'Benutzer',
           'settings' => 'Einstellungen',
           'files' => 'Dateien',
           'stats' => 'Statistiken'
       ]
    ];
    return $lang_array[$_SERVER['mngr_lang']][$id];

}
$web_server = new WebServer();
exec('hostname -I', $ip);
$_SERVER['mngr_ip'] = str_replace(' ', '', $ip[0]);
$_SERVER['mngr_root'] = 'https://' . $_SERVER['mngr_ip'];
$_SERVER['mngr_title'] = 'siteMngr';
$session = new Session();
if (!(isset($_SESSION['user']) && isset($_SERVER['mngr_users'][$_SESSION['user']]) && $_SERVER['mngr_users'][$_SESSION['user']] == $_SESSION['password_hash']))
{
    if (!(isset($_POST['user']) && isset($_POST['password']) && isset($_SESSION['login_tries'])))
    {
        $body = '<div style="-ms-display:table;-webkit-display:table;-moz-display:table;display:table;-ms-position:absolute;-webkit-position:absolute;-moz-position:absolute;position:absolute;height:100%;width:100%"><div style="-ms-display:table-cell;-webkit-display:table-cell;-moz-display:table-cell;display:table-cell;-ms-vertical-align:middle;-webkit-vertical-align:middle;-moz-vertical-align:middle;vertical-align:middle;text-align:center!important"><div class="box border" style="border-color:#ccc;padding:10px!important;display:inline-block!important;text-align:left!important"><h2>siteMngr - ' . tr('login') . '&nbsp;</h2><form action="' . $_SERVER['mngr_root'] . '" method="post"><label for="user" class="bold">' . tr('username') . ':</label><br><input id="user" type="text" name="user" class="full' . $_SERVER['mngr_corner'] . '" placeholder="' . tr('username') . '"><br><br><label for="password" class="bold">' . tr('password') . ':</label><br><input id="password" type="password" name="password" class="full' . $_SERVER['mngr_corner'] . '" placeholder="' . tr('password') . '"><br><br><input type="submit" class="' . $_SERVER['mngr_corner_b'] . '" value="' . tr('login') . '"></form></div></div></div>';
        $_SESSION['login_tries'] = 0;
        $_SERVER['is_logged_in'] = false;
    }
    else
    {
        $_SESSION['login_tries']++;
        if ($_SESSION['login_tries'] > 5)
        {
            $body = '<div style="-ms-display:table;-webkit-display:table;-moz-display:table;display:table;-ms-position:absolute;-webkit-position:absolute;-moz-position:absolute;position:absolute;height:100%;width:100%"><div style="-ms-display:table-cell;-webkit-display:table-cell;-moz-display:table-cell;display:table-cell;-ms-vertical-align:middle;-webkit-vertical-align:middle;-moz-vertical-align:middle;vertical-align:middle;text-align:center!important"><div class="box border" style="border-color:#ccc;padding:10px!important;display:inline-block!important;text-align:left!important"><h2>siteMngr - ' . tr('login') . '&nbsp;</h2><span class="red bold">' . tr('error_false_data') . '</span><br><br><form action="' . $_SERVER['mngr_root'] . '" method="post"><label for="name" class="bold">' . tr('username') . ':</label><br><input id="name" type="text" name="user" class="full' . $_SERVER['mngr_corner'] . '" placeholder="' . tr('username') . '"><br><br><label for="password" class="bold">' . tr('password') . ':</label><br><input id="password" type="password" name="password" class="full' . $_SERVER['mngr_corner'] . '" placeholder="' . tr('password') . '"><br><br><input type="submit" class="' . $_SERVER['mngr_corner_b'] . '" value="' . tr('login') . '"></form></div></div></div>';
            $_SERVER['mngr_title'] = 'siteMngr - ' . tr('login') . ' - ' . tr('error');
            $_SERVER['is_logged_in'] = false;
        }
        else
        {
            if (isset($_SERVER['mngr_users'][$_POST['user']]) && $_SERVER['mngr_users'][$_POST['user']] == sha512($_POST['password']))
            {
                $_SESSION['user'] = $_POST['user'];
                $_SESSION['password_hash'] = $_SERVER['mngr_users'][$_POST['user']];
                $_SERVER['is_logged_in'] = true;
                $_SESSION['login_tries'] = 0;
                $_SESSION['home_path'] = '';
                $_SESSION['default_url'] = '';
            }
            else
            {
                $body = '<div style="-ms-display:table;-webkit-display:table;-moz-display:table;display:table;-ms-position:absolute;-webkit-position:absolute;-moz-position:absolute;position:absolute;height:100%;width:100%"><div style="-ms-display:table-cell;-webkit-display:table-cell;-moz-display:table-cell;display:table-cell;-ms-vertical-align:middle;-webkit-vertical-align:middle;-moz-vertical-align:middle;vertical-align:middle;text-align:center!important"><div class="box border" style="border-color:#ccc;padding:10px!important;display:inline-block!important;text-align:left!important"><h2>siteMngr - ' . tr('login') . '&nbsp;</h2><span class="red bold">' . tr('error_false_data') . '</span><br><br><form action="' . $_SERVER['mngr_root'] . '" method="post"><label for="name" class="bold">' . tr('username') . ':</label><br><input id="name" type="text" name="user" class="full' . $_SERVER['mngr_corner'] . '" placeholder="' . tr('username') . '"><br><br><label for="password" class="bold">' . tr('password') . ':</label><br><input id="password" type="password" name="password" class="full' . $_SERVER['mngr_corner'] . '" placeholder="' . tr('password') . '"><br><br><input type="submit" class="' . $_SERVER['mngr_corner_b'] . '" value="' . tr('login') . '"></form></div></div></div>';
                $_SERVER['mngr_title'] = 'siteMngr - ' . tr('login') . ' - ' . tr('error');
                $_SERVER['is_logged_in'] = false;
            }
        }
    }
}
else
{
    $_SERVER['is_logged_in'] = true;
}
if ($_SERVER['is_logged_in'] == true)
{
    #$body .= '<nav></nav>';
    $body = '<div class="main sidebar-left">';
    $body .= '<div class="sidebar sidebar-'.$_SERVER['mngr_color'].'">
    <a class="pointer sites">'.tr('sites').'</a>
    <a class="pointer files">'.tr('files').'</a>
    <a class="pointer stats">'.tr('stats').'</a>
    <a class="pointer users">'.tr('users').'</a>
    <a class="pointer settings">'.tr('settings').'</a>  </div><div class="content" style="padding-top:1rem"><br>
    <h2>CPU:</h2>
    <div class="progress"><div class="bar cpu bg-red" style="width:100%"></div></div><hr>
    <h2>RAM:</h2>
    <div class="progress"><div class="bar ram bg-red" style="width:100%"></div></div>
<hr>
<hr>
    <label class="dropdown">
        <span class="button">Design</span>
        <input type="checkbox">
        <ul>
            <li val="green" onclick="design(this)">Grün</li>
            <li val="black" onclick="design(this)">Schwarz</li>
            <li val="red" onclick="design(this)">Rot</li>
            <li val="yellow" onclick="design(this)">Gelb</li>
            <li val="blue" onclick="design(this)">Blau</li>
            <li val="gray" onclick="design(this)">Grau</li>
        </ul>
    </label>
    <label class="dropdown">
        <span class="button">Abgerundet/Kanten</span>
        <input type="checkbox">
        <ul>
            <li val="true" onclick="rc(this)">Kanten</li>
            <li val="false" onclick="rc(this)">Abgerundet</li>
        </ul>
    </label>
    
    <script>
    function rc(p)
    {
        const xhttpk = new XMLHttpRequest();
        xhttpk.onload = function() {
          new Toast("Abgerundet/Kanten aktualisiert<br>Hier klicken um Seite neu zu laden",function(){window.location.reload();});
        }
        xhttpk.open("GET", "ajax.php?action=rc&data=" + p.attributes[0].value, true);
        xhttpk.send();
    }
    function design(p)
    {
        const xhttpg = new XMLHttpRequest();
        xhttpg.onload = function() {
          new Toast("Design aktualisiert<br>Hier klicken um Seite neu zu laden",function(){window.location.reload();});
        }
        xhttpg.open("GET", "ajax.php?action=design&data=" + p.attributes[0].value, true);
        xhttpg.send();
    }
    function ajax() {
        const xhttp = new XMLHttpRequest();
        xhttp.onload = function() {
          var ram = this.responseText.split(";")[1];
          var cpu = this.responseText.split(";")[0];
          $(".cpu").style="width:" + cpu + "%";
          $(".ram").style="width:" + ram + "%";
          if (ram > 69)
          {
            $(".ram").className = "progress ram bg-red";
          }
          else if (ram > 49)
          {
            $(".ram").className = "progress ram bg-yellow";
          }
          else
          {
            $(".ram").className = "progress ram bg-green";
          }
          if (cpu > 69)
          {
            $(".cpu").className = "progress cpu bg-red";
          }
          else if (cpu > 49)
          {
            $(".cpu").className = "progress cpu bg-yellow";
          }
          else
          {
            $(".cpu").className = "progress cpu bg-green";
          }
        }
        xhttp.open("GET", "ajax.php?action=getload", true);
        xhttp.send();
      }
      window.setInterval(ajax, 500);</script></div>';
    $body .= '<script>
    $(".files").on("click", function(){
        $(".content").innerHTML = \'<style>html,body,iframe,.content,.main{height:100%}.main{margin-right:0!important}.content{padding:0px!important}</style><iframe src="/fm" style="border:none;width:100%"></iframe>\';
        $("body").style.overflow = "hidden";
    });
    </script>';
    //$body .= '<br><hr><br><a class="button' . $_SERVER['mngr_corner'] . '" href="' . $_SERVER['mngr_root'] . '/ajax.php?action=logout">' . tr('logout') . '</a><br></div>';
    $body .= '</div>';
}
$html_struct = ['<!DOCTYPE html>',
'<html>',
'<head>',
'<meta charset="UTF-8" />',
'<meta name="viewport" content="width=device-width, initial-scale=1.0" />',
'<link rel="shortcut icon" type="image/x-icon" href="' . $_SERVER['mngr_root'] . '/favicon.ico" />',
'<link rel="icon" type="image/png" sizes="32x32" href="' . $_SERVER['mngr_root'] . '/favicon-32x32.png" />',
'<link rel="icon" type="image/png" sizes="16x16" href="' . $_SERVER['mngr_root'] . '/favicon-16x16.png" />',
'<title>' . $_SERVER['mngr_title'] . '</title>',
'<link rel="stylesheet" type="text/css" href="' . $_SERVER['mngr_root'] . '/all.css">',
'<script src="' . $_SERVER['mngr_root'] . '/all.js"></script>',
'</head>',
'<body class="sitefactorycss-' . $_SERVER['mngr_color'] . '">',
$body,
'</body>',
'</html>'];
$html_struct = implode('', $html_struct);
echo $html_struct;
?>