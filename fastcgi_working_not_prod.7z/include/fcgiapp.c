/* Copyright (c) 1996 Open Market, Inc.
This FastCGI application library source and object code (the
"Software") and its documentation (the "Documentation") are
copyrighted by Open Market, Inc ("Open Market").  The following terms
apply to all files associated with the Software and Documentation
unless explicitly disclaimed in individual files.

Open Market permits you to use, copy, modify, distribute, and license
this Software and the Documentation for any purpose, provided that
existing copyright notices are retained in all copies and that this
notice is included verbatim in any distributions.  No written
agreement, license, or royalty fee is required for any of the
authorized uses.  Modifications to this Software and Documentation may
be copyrighted by their authors and need not follow the licensing
terms described here.  If modifications to this Software and
Documentation have new licensing terms, the new terms must be clearly
indicated on the first page of each file where they apply.

OPEN MARKET MAKES NO EXPRESS OR IMPLIED WARRANTY WITH RESPECT TO THE
SOFTWARE OR THE DOCUMENTATION, INCLUDING WITHOUT LIMITATION ANY
WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  IN
NO EVENT SHALL OPEN MARKET BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY
DAMAGES ARISING FROM OR RELATING TO THIS SOFTWARE OR THE
DOCUMENTATION, INCLUDING, WITHOUT LIMITATION, ANY INDIRECT, SPECIAL OR
CONSEQUENTIAL DAMAGES OR SIMILAR DAMAGES, INCLUDING LOST PROFITS OR
LOST DATA, EVEN IF OPEN MARKET HAS BEEN ADVISED OF THE POSSIBILITY OF
SUCH DAMAGES.  THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS".
OPEN MARKET HAS NO LIABILITY IN CONTRACT, TORT, NEGLIGENCE OR
OTHERWISE ARISING OUT OF THIS SOFTWARE OR THE DOCUMENTATION.
*/

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <limits.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <signal.h>
#include <unistd.h>
#ifndef _CLIENTDATA
typedef int *ClientData;
#define _CLIENTDATA
#endif
typedef void (*OS_AsyncProc) (ClientData clientData, int len);
typedef struct {
    unsigned char version;
    unsigned char type;
    unsigned char requestIdB1;
    unsigned char requestIdB0;
    unsigned char contentLengthB1;
    unsigned char contentLengthB0;
    unsigned char paddingLength;
    unsigned char reserved;
} FCGI_Header;
typedef struct {
    unsigned char roleB1;
    unsigned char roleB0;
    unsigned char flags;
    unsigned char reserved[5];
} FCGI_BeginRequestBody;
typedef struct {
    FCGI_Header header;
    FCGI_BeginRequestBody body;
} FCGI_BeginRequestRecord;
typedef struct {
    unsigned char appStatusB3;
    unsigned char appStatusB2;
    unsigned char appStatusB1;
    unsigned char appStatusB0;
    unsigned char protocolStatus;
    unsigned char reserved[3];
} FCGI_EndRequestBody;
typedef struct {
    FCGI_Header header;
    FCGI_EndRequestBody body;
} FCGI_EndRequestRecord;
typedef struct {
    unsigned char type;    
    unsigned char reserved[7];
} FCGI_UnknownTypeBody;
typedef struct {
    FCGI_Header header;
    FCGI_UnknownTypeBody body;
} FCGI_UnknownTypeRecord;
#ifndef FALSE
#define FALSE (0)
#endif
#ifndef TRUE
#define TRUE  (1)
#endif
#ifndef min
#define min(a,b) ((a) < (b) ? (a) : (b))
#endif
#ifndef max
#define max(a,b) ((a) > (b) ? (a) : (b))
#endif
typedef struct {
    OS_AsyncProc procPtr;
    ClientData clientData;
    int fd;
    int len;
    int offset;
    void *buf;
    int inUse;
} AioInfo;
#define AIO_RD_IX(fd) (fd * 2)
#define AIO_WR_IX(fd) ((fd * 2) + 1)
static int asyncIoInUse = FALSE;
static int asyncIoTableSize = 16;
static AioInfo *asyncIoTable = NULL;
static int libInitialized = FALSE;
static fd_set readFdSet;
static fd_set writeFdSet;
static fd_set readFdSetPost;
static int numRdPosted = 0;
static fd_set writeFdSetPost;
static int numWrPosted = 0;
static int volatile maxFd = -1;
static int shutdownPending = FALSE;
static int shutdownNow = FALSE;
void OS_ShutdownPending()
{
    shutdownPending = TRUE;
}
static void OS_Sigusr1Handler(int signo)
{
    OS_ShutdownPending();
}
static void OS_SigpipeHandler(int signo)
{
    ;
}
static void installSignalHandler(int signo, const struct sigaction * act, int force)
{
    struct sigaction sa;
    sigaction(signo, NULL, &sa);
    if (force || sa.sa_handler == SIG_DFL || sa.sa_handler == SIG_IGN) {
        sigaction(signo, act, NULL);
    }
}
static void OS_InstallSignalHandlers(int force)
{
    struct sigaction sa;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = OS_SigpipeHandler;
    installSignalHandler(SIGPIPE, &sa, force);
    sa.sa_handler = OS_Sigusr1Handler;
    installSignalHandler(SIGUSR1, &sa, force);
    installSignalHandler(SIGTERM, &sa, 0);
}
int OS_LibInit(int stdioFds[3])
{
    if(libInitialized)
        return 0;
    asyncIoTable = (AioInfo *)malloc(asyncIoTableSize * sizeof(AioInfo));
    if(asyncIoTable == NULL) {
        errno = ENOMEM;
        return -1;
    }
    memset((char *) asyncIoTable, 0, asyncIoTableSize * sizeof(AioInfo));
    FD_ZERO(&readFdSet);
    FD_ZERO(&writeFdSet);
    FD_ZERO(&readFdSetPost);
    FD_ZERO(&writeFdSetPost);
    OS_InstallSignalHandlers(FALSE);
    libInitialized = TRUE;
    return 0;
}
void OS_LibShutdown()
{
    if(!libInitialized)
        return;
    free(asyncIoTable);
    asyncIoTable = NULL;
    libInitialized = FALSE;
    return;
}
static int OS_BuildSockAddrUn(const char *bindPath, struct sockaddr_un *servAddrPtr, int *servAddrLen)
{
    int bindPathLen = strlen(bindPath);
#ifdef HAVE_SOCKADDR_UN_SUN_LEN
    if(bindPathLen >= sizeof(servAddrPtr->sun_path)) {
        return -1;
    }
#else
    if(bindPathLen > sizeof(servAddrPtr->sun_path)) {
        return -1;
    }
#endif
    memset((char *) servAddrPtr, 0, sizeof(*servAddrPtr));
    servAddrPtr->sun_family = AF_UNIX;
    memcpy(servAddrPtr->sun_path, bindPath, bindPathLen);
#ifdef HAVE_SOCKADDR_UN_SUN_LEN
    *servAddrLen = sizeof(servAddrPtr->sun_len) + sizeof(servAddrPtr->sun_family) + bindPathLen + 1;
    servAddrPtr->sun_len = *servAddrLen;
#else
    *servAddrLen = sizeof(servAddrPtr->sun_family) + bindPathLen;
#endif
    return 0;
}
union SockAddrUnion {
    struct sockaddr_un	unixVariant;
    struct sockaddr_in	inetVariant;
};
static void GrowAsyncTable(void)
{
    int oldTableSize = asyncIoTableSize;
    asyncIoTableSize = asyncIoTableSize * 2;
    asyncIoTable = (AioInfo *)realloc(asyncIoTable, asyncIoTableSize * sizeof(AioInfo));
    if(asyncIoTable == NULL) {
        errno = ENOMEM;
        exit(errno);
    }
    memset((char *) &asyncIoTable[oldTableSize], 0, oldTableSize * sizeof(AioInfo));
}
int OS_AsyncRead(int fd, int offset, void *buf, int len, OS_AsyncProc procPtr, ClientData clientData)
{
    int index = AIO_RD_IX(fd);
    assert(asyncIoTable != NULL);
    asyncIoInUse = TRUE;
    if(fd > maxFd)
        maxFd = fd;
    while (index >= asyncIoTableSize) {
        GrowAsyncTable();
    }
    assert(asyncIoTable[index].inUse == 0);
    asyncIoTable[index].procPtr = procPtr;
    asyncIoTable[index].clientData = clientData;
    asyncIoTable[index].fd = fd;
    asyncIoTable[index].len = len;
    asyncIoTable[index].offset = offset;
    asyncIoTable[index].buf = buf;
    asyncIoTable[index].inUse = 1;
    FD_SET(fd, &readFdSet);
    return 0;
}
int OS_Close(int fd, int shutdown_ok)
{
    if (fd == -1)
        return 0;
    if (asyncIoInUse) {
        int index = AIO_RD_IX(fd);
        FD_CLR(fd, &readFdSet);
        FD_CLR(fd, &readFdSetPost);
        if (asyncIoTable[index].inUse != 0) {
            asyncIoTable[index].inUse = 0;
        }
        FD_CLR(fd, &writeFdSet);
        FD_CLR(fd, &writeFdSetPost);
        index = AIO_WR_IX(fd);
        if (asyncIoTable[index].inUse != 0) {
            asyncIoTable[index].inUse = 0;
        }
        if (maxFd == fd) {
            maxFd--;
        }
    }
    if (shutdown_ok)
    {
        if (shutdown(fd, 1) == 0)
        {
            struct timeval tv;
            fd_set rfds;
            int rv;
            char trash[1024];
            FD_ZERO(&rfds);
            do {
                FD_SET(fd, &rfds);
                tv.tv_sec = 2;
                tv.tv_usec = 0;
                rv = select(fd + 1, &rfds, NULL, NULL, &tv);
            }
            while (rv > 0 && read(fd, trash, sizeof(trash)) > 0);
        }
    }
    return close(fd);
}
static char * str_dup(const char * str)
{
	int len = strlen(str) + 1;
    char * sdup = (char *)malloc(len);
    if (sdup) {
        memcpy(sdup, str, len);
    }
    return sdup;
}
static int ClientAddrOK(struct sockaddr_in *saPtr, const char *clientList)
{
    int result = FALSE;
    char *clientListCopy, *cur, *next;
    if (clientList == NULL || *clientList == '\0') {
        return TRUE;
    }
    clientListCopy = str_dup(clientList);
    for (cur = clientListCopy; cur != NULL; cur = next) {
        next = strchr(cur, ',');
        if (next != NULL) {
            *next++ = '\0';
        }
        if (inet_addr(cur) == saPtr->sin_addr.s_addr) {
            result = TRUE;
            break;
        }
    }
    free(clientListCopy);
    return result;
}
static int AcquireLock(int sock, int fail_on_intr)
{
#ifdef USE_LOCKING
    do {
        struct flock lock;
        lock.l_type = F_WRLCK;
        lock.l_start = 0;
        lock.l_whence = SEEK_SET;
        lock.l_len = 0;

        if (fcntl(sock, F_SETLKW, &lock) != -1)
            return 0;
    } while (errno == EINTR 
             && ! fail_on_intr 
             && ! shutdownPending);

    return -1;

#else
    return 0;
#endif
}
static int ReleaseLock(int sock)
{
#ifdef USE_LOCKING
    do {
        struct flock lock;
        lock.l_type = F_UNLCK;
        lock.l_start = 0;
        lock.l_whence = SEEK_SET;
        lock.l_len = 0;

        if (fcntl(sock, F_SETLK, &lock) != -1)
            return 0;
    } while (errno == EINTR);

    return -1;

#else
    return 0;
#endif
}
static int is_reasonable_accept_errno (const int error)
{
    switch (error) {
#ifdef EPROTO
        case EPROTO:
#endif
#ifdef ECONNABORTED
        case ECONNABORTED:
#endif
#ifdef ECONNRESET
        case ECONNRESET:
#endif
#ifdef ETIMEDOUT
        case ETIMEDOUT:
#endif
#ifdef EHOSTUNREACH
        case EHOSTUNREACH:
#endif
#ifdef ENETUNREACH
        case ENETUNREACH:
#endif
            return 1;
        default:
            return 0;
    }
}
static int is_af_unix_keeper(const int fd)
{
    struct timeval tval = { 2,0 };
    fd_set read_fds;
    FD_ZERO(&read_fds);
    FD_SET(fd, &read_fds);
    return select(fd + 1, &read_fds, NULL, NULL, &tval) >= 0 && FD_ISSET(fd, &read_fds);
}
int OS_Accept(int listen_sock, int fail_on_intr, const char *webServerAddrs)
{
    int socket = -1;
    union {
        struct sockaddr_un un;
        struct sockaddr_in in;
    } sa;
    for (;;) {
        if (AcquireLock(listen_sock, fail_on_intr))
            return -1;
        for (;;) {
            do {
#ifdef HAVE_SOCKLEN
                socklen_t len = sizeof(sa);
#else
                int len = sizeof(sa);
#endif
                if (shutdownPending) break;
                socket = accept(listen_sock, (struct sockaddr *)&sa, &len);
            } while (socket < 0 
                     && errno == EINTR 
                     && ! fail_on_intr 
                     && ! shutdownPending);
            if (socket < 0) {
                if (shutdownPending || ! is_reasonable_accept_errno(errno)) {
                    int errnoSave = errno;
                    ReleaseLock(listen_sock);
                    if (! shutdownPending) {
                        errno = errnoSave;
                    }
                    return (-1);
                }
                errno = 0;
            }
            else {
                int set = 1;
                if (sa.in.sin_family != AF_INET)
                    break;
#ifdef TCP_NODELAY
                setsockopt(socket, IPPROTO_TCP, TCP_NODELAY, (char *)&set, sizeof(set));
#endif
                if (ClientAddrOK(&sa.in, webServerAddrs))
                    break;
                close(socket);
            }
        }
        if (ReleaseLock(listen_sock))
            return (-1);
        if (sa.in.sin_family != AF_UNIX || is_af_unix_keeper(socket))
            break;
        close(socket);
    }
    return (socket);
}
int OS_IpcClose(int ipcFd, int shutdown)
{
    return OS_Close(ipcFd, shutdown);
}
int OS_IsFcgi(int sock)
{
	union {
        struct sockaddr_in in;
        struct sockaddr_un un;
    } sa;
#ifdef HAVE_SOCKLEN
    socklen_t len = sizeof(sa);
#else
    int len = sizeof(sa);
#endif
    errno = 0;
    if (getpeername(sock, (struct sockaddr *)&sa, &len) != 0 && errno == ENOTCONN) {
        return TRUE;
    }
    else {
        return FALSE;
    }
}
typedef struct FCGX_Stream {
    unsigned char *rdNext;
    unsigned char *wrNext;
    unsigned char *stop;
    unsigned char *stopUnget;
    int isReader;
    int isClosed;
    int wasFCloseCalled;
    int FCGI_errno;
    void (*fillBuffProc) (struct FCGX_Stream *stream);
    void (*emptyBuffProc) (struct FCGX_Stream *stream, int doClose);
    void *data;
} FCGX_Stream;
typedef char **FCGX_ParamArray;
typedef struct FCGX_Request {
    int requestId;
    int role;
    FCGX_Stream *in;
    FCGX_Stream *out;
    FCGX_Stream *err;
    char **envp;
    struct Params *paramsPtr;
    int ipcFd;
    int isBeginProcessed;
    int keepConnection;
    int appStatus;
    int nWriters;
    int flags;
    int listen_sock;
    int detached;
} FCGX_Request;
int FCGX_Init(void);
int FCGX_InitRequest(FCGX_Request *request, int sock, int flags);
void FCGX_Free(FCGX_Request * request, int close);
int FCGX_GetChar(FCGX_Stream *stream);
int FCGX_GetStr(char *str, int n, FCGX_Stream *stream);
int FCGX_PutStr(const char *str, int n, FCGX_Stream *stream);
int FCGX_Flush(FCGX_Stream *stream);
int FCGX_FClose(FCGX_Stream *stream);
int FCGX_GetError(FCGX_Stream *stream);
void FCGX_FreeStream(FCGX_Stream **stream);
#ifdef HAVE_VA_ARG_LONG_DOUBLE_BUG
#define LONG_DOUBLE double
#else
#define LONG_DOUBLE long double
#endif
static int isFastCGI = -1;
static char *webServerAddressList = NULL;
static FCGX_Request the_request;
static void *Malloc(size_t size)
{
    void *result = malloc(size);
    assert(size == 0 || result != NULL);
    return result;
}
static char *StringCopy(char *str)
{
    int strLen = strlen(str);
    char *newString = (char *)Malloc(strLen + 1);
    memcpy(newString, str, strLen);
    newString[strLen] = '\000';
    return newString;
}
int FCGX_GetChar(FCGX_Stream *stream)
{
    if (stream->isClosed || ! stream->isReader)
        return -1;
    if (stream->rdNext != stream->stop)
        return *stream->rdNext++;
    stream->fillBuffProc(stream);
    if (stream->isClosed)
        return -1;
    stream->stopUnget = stream->rdNext;
    if (stream->rdNext != stream->stop)
        return *stream->rdNext++;
    assert(stream->isClosed);
    return -1;
}
int FCGX_GetStr(char *str, int n, FCGX_Stream *stream)
{
    int m, bytesMoved;
    if (stream->isClosed || ! stream->isReader || n <= 0) {
        return 0;
    }
    if(n <= (stream->stop - stream->rdNext)) {
        memcpy(str, stream->rdNext, n);
        stream->rdNext += n;
        return n;
    }
    bytesMoved = 0;
    for (;;) {
        if(stream->rdNext != stream->stop) {
            m = min(n - bytesMoved, stream->stop - stream->rdNext);
            memcpy(str, stream->rdNext, m);
            bytesMoved += m;
            stream->rdNext += m;
            if(bytesMoved == n)
                return bytesMoved;
            str += m;
        }
        if(stream->isClosed || !stream->isReader)
            return bytesMoved;
        stream->fillBuffProc(stream);
        if (stream->isClosed)
            return bytesMoved;
        stream->stopUnget = stream->rdNext;
    }
}
int FCGX_UnGetChar(int c, FCGX_Stream *stream) {
    if(c == -1 || stream->isClosed || !stream->isReader || stream->rdNext == stream->stopUnget)
        return -1;
    --(stream->rdNext);
    *stream->rdNext = (unsigned char) c;
    return c;
}
int FCGX_PutStr(const char *str, int n, FCGX_Stream *stream)
{
    int m, bytesMoved;
    if(n <= (stream->stop - stream->wrNext)) {
        memcpy(stream->wrNext, str, n);
        stream->wrNext += n;
        return n;
    }
    bytesMoved = 0;
    for (;;) {
        if(stream->wrNext != stream->stop) {
            m = min(n - bytesMoved, stream->stop - stream->wrNext);
            memcpy(stream->wrNext, str, m);
            bytesMoved += m;
            stream->wrNext += m;
            if(bytesMoved == n)
                return bytesMoved;
            str += m;
	}
        if(stream->isClosed || stream->isReader)
            return -1;
        stream->emptyBuffProc(stream, FALSE);
    }
}
int Print(FCGX_Stream *stream, char *str)
{
    int m, bytesMoved, n = strlen(str);
    if(n <= (stream->stop - stream->wrNext)) {
        memcpy(stream->wrNext, str, n);
        stream->wrNext += n;
        return 0;
    }
    bytesMoved = 0;
    for (;;) {
        if(stream->wrNext != stream->stop) {
            m = min(n - bytesMoved, stream->stop - stream->wrNext);
            memcpy(stream->wrNext, str, m);
            bytesMoved += m;
            stream->wrNext += m;
            if(bytesMoved == n)
                return 0;
            str += m;
	}
        if(stream->isClosed || stream->isReader)
            return 0;
        stream->emptyBuffProc(stream, FALSE);
    }
}
static void CopyAndAdvance(char **destPtr, char **srcPtr, int n)
{
    char *dest = *destPtr;
    char *src = *srcPtr;
    int i;
    for (i = 0; i < n; i++)
        *dest++ = *src++;
    *destPtr = dest;
    *srcPtr = src;
}
int FCGX_Flush(FCGX_Stream *stream)
{
    if(stream->isClosed || stream->isReader)
        return 0;
    stream->emptyBuffProc(stream, FALSE);
    return (stream->isClosed) ? -1 : 0;
}
int FCGX_FClose(FCGX_Stream *stream)
{
    if (stream == NULL) return 0;
    if(!stream->wasFCloseCalled) {
        if(!stream->isReader) {
            stream->emptyBuffProc(stream, TRUE);
        }
        stream->wasFCloseCalled = TRUE;
        stream->isClosed = TRUE;
        if(stream->isReader) {
            stream->wrNext = stream->stop = stream->rdNext;
        } else {
            stream->rdNext = stream->stop = stream->wrNext;
        }
    }
    return (stream->FCGI_errno == 0) ? 0 : -1;
}
static void SetError(FCGX_Stream *stream, int FCGI_errno)
{
    if(stream->FCGI_errno == 0) {
        stream->FCGI_errno = FCGI_errno;
    }
    stream->isClosed = TRUE;
}
int FCGX_GetError(FCGX_Stream *stream) {
    return stream->FCGI_errno;
}
typedef struct Params {
    FCGX_ParamArray vec;
    int length;
    char **cur;
} Params;
typedef Params *ParamsPtr;
static ParamsPtr NewParams(int length)
{
    ParamsPtr result;
    result = (Params *)Malloc(sizeof(Params));
    result->vec = (char **)Malloc(length * sizeof(char *));
    result->length = length;
    result->cur = result->vec;
    *result->cur = NULL;
    return result;
}
static void FreeParams(ParamsPtr *paramsPtrPtr)
{
    ParamsPtr paramsPtr = *paramsPtrPtr;
    char **p;
    if(paramsPtr == NULL) {
        return;
    }
    for (p = paramsPtr->vec; p < paramsPtr->cur; p++) {
        free(*p);
    }
    free(paramsPtr->vec);
    free(paramsPtr);
    *paramsPtrPtr = NULL;
}
static void PutParam(ParamsPtr paramsPtr, char *nameValue)
{
    int size;
    *paramsPtr->cur++ = nameValue;
    size = paramsPtr->cur - paramsPtr->vec;
    if(size >= paramsPtr->length) {
	paramsPtr->length *= 2;
	paramsPtr->vec = (FCGX_ParamArray)realloc(paramsPtr->vec, paramsPtr->length * sizeof(char *));
	paramsPtr->cur = paramsPtr->vec + size;
    }
    *paramsPtr->cur = NULL;
}
char *FCGX_GetParam(const char *name, FCGX_ParamArray envp)
{
    int len;
    char **p;
	if (name == NULL || envp == NULL) return NULL;
    len = strlen(name);
    for (p = envp; *p; ++p) {
        if((strncmp(name, *p, len) == 0) && ((*p)[len] == '=')) {
            return *p+len+1;
        }
    }
    return NULL;
}
static int ReadParams(Params *paramsPtr, FCGX_Stream *stream)
{
    int nameLen, valueLen;
    unsigned char lenBuff[3];
    char *nameValue;
    while((nameLen = FCGX_GetChar(stream)) != -1) {
        if((nameLen & 0x80) != 0) {
            if(FCGX_GetStr((char *) &lenBuff[0], 3, stream) != 3) {
                SetError(stream, -4);
                return -1;
	    }
            nameLen = ((nameLen & 0x7f) << 24) + (lenBuff[0] << 16)
                    + (lenBuff[1] << 8) + lenBuff[2];
        }
        if((valueLen = FCGX_GetChar(stream)) == -1) {
            SetError(stream, -4);
            return -1;
	}
        if((valueLen & 0x80) != 0) {
            if(FCGX_GetStr((char *) &lenBuff[0], 3, stream) != 3) {
                SetError(stream, -4);
                return -1;
	    }
            valueLen = ((valueLen & 0x7f) << 24) + (lenBuff[0] << 16)
                    + (lenBuff[1] << 8) + lenBuff[2];
        }
        nameValue = (char *)Malloc(nameLen + valueLen + 2);
        if(FCGX_GetStr(nameValue, nameLen, stream) != nameLen) {
            SetError(stream, -4);
            free(nameValue);
            return -1;
	}
        *(nameValue + nameLen) = '=';
        if(FCGX_GetStr(nameValue + nameLen + 1, valueLen, stream)
                != valueLen) {
            SetError(stream, -4);
            free(nameValue);
            return -1;
	}
        *(nameValue + nameLen + valueLen + 1) = '\0';
        PutParam(paramsPtr, nameValue);
    }
    return 0;
}
static FCGI_Header MakeHeader(int type, int requestId, int contentLength, int paddingLength)
{
    FCGI_Header header;
    assert(contentLength >= 0 && contentLength <= 0xffff);
    assert(paddingLength >= 0 && paddingLength <= 0xff);
    header.version = 1;
    header.type = (unsigned char) type;
    header.requestIdB1 = (unsigned char) ((requestId >> 8) & 0xff);
    header.requestIdB0 = (unsigned char) ((requestId ) & 0xff);
    header.contentLengthB1 = (unsigned char) ((contentLength >> 8) & 0xff);
    header.contentLengthB0 = (unsigned char) ((contentLength) & 0xff);
    header.paddingLength = (unsigned char) paddingLength;
    header.reserved = 0;
    return header;
}
static FCGI_EndRequestBody MakeEndRequestBody(int appStatus, int protocolStatus)
{
    FCGI_EndRequestBody body;
    body.appStatusB3 = (unsigned char) ((appStatus >> 24) & 0xff);
    body.appStatusB2 = (unsigned char) ((appStatus >> 16) & 0xff);
    body.appStatusB1 = (unsigned char) ((appStatus >>  8) & 0xff);
    body.appStatusB0 = (unsigned char) ((appStatus) & 0xff);
    body.protocolStatus = (unsigned char) protocolStatus;
    memset(body.reserved, 0, sizeof(body.reserved));
    return body;
}
static FCGI_UnknownTypeBody MakeUnknownTypeBody(int type)
{
    FCGI_UnknownTypeBody body;
    body.type = (unsigned char) type;
    memset(body.reserved, 0, sizeof(body.reserved));
    return body;
}
static int AlignInt8(unsigned n) {
    return (n + 7) & (UINT_MAX - 7);
}
static unsigned char *AlignPtr8(unsigned char *p) {
    unsigned long u = (unsigned long) p;
    u = ((u + 7) & (ULONG_MAX - 7)) - u;
    return p + u;
}
typedef struct FCGX_Stream_Data {
    unsigned char *buff;
    int bufflen;
    unsigned char *mBuff;
    unsigned char *buffStop;
    int type;
    int eorStop;
    int skip;
    int contentLen;
    int paddingLen;
    int isAnythingWritten;
    int rawWrite;
    FCGX_Request *reqDataPtr;
} FCGX_Stream_Data;
static void WriteCloseRecords(struct FCGX_Stream *stream)
{
    FCGX_Stream_Data *data = (FCGX_Stream_Data *)stream->data;
    data->rawWrite = TRUE;
    if(!(data->type == 7 && stream->wrNext == data->buff && !data->isAnythingWritten)) {
        FCGI_Header header;
        header = MakeHeader(data->type, data->reqDataPtr->requestId, 0, 0);
        FCGX_PutStr((char *) &header, sizeof(header), stream);
    };
    if(data->reqDataPtr->nWriters == 1) {
        FCGI_EndRequestRecord endRequestRecord;
        endRequestRecord.header = MakeHeader(3, data->reqDataPtr->requestId, sizeof(endRequestRecord.body), 0);
        endRequestRecord.body = MakeEndRequestBody(data->reqDataPtr->appStatus, 0);
        FCGX_PutStr((char *) &endRequestRecord, sizeof(endRequestRecord), stream);
    }
    data->reqDataPtr->nWriters--;
}
static int write_it_all(int fd, char *buf, int len)
{
    int wrote;
    while (len) {
        wrote = write(fd, buf, len);
        if (wrote < 0)
            return wrote;
        len -= wrote;
        buf += wrote;
    }
    return len;
}
static void EmptyBuffProc(struct FCGX_Stream *stream, int doClose)
{
    FCGX_Stream_Data *data = (FCGX_Stream_Data *)stream->data;
    int cLen, eLen;
    if(!data->rawWrite) {
        cLen = stream->wrNext - data->buff - sizeof(FCGI_Header);
        if(cLen > 0) {
            eLen = AlignInt8(cLen);
            memset(stream->wrNext, 0, eLen - cLen);
            stream->wrNext += eLen - cLen;
            *((FCGI_Header *) data->buff) = MakeHeader(data->type, data->reqDataPtr->requestId, cLen, eLen - cLen);
        } else {
            stream->wrNext = data->buff;
	}
    }
    if(doClose) {
        WriteCloseRecords(stream);
    };
    if (stream->wrNext != data->buff) {
        data->isAnythingWritten = TRUE;
        if (write_it_all(data->reqDataPtr->ipcFd, (char *)data->buff, stream->wrNext - data->buff) < 0) {
            SetError(stream, errno);
            return;
        }
        stream->wrNext = data->buff;
    }
    if(!data->rawWrite) {
        stream->wrNext += sizeof(FCGI_Header);
    }
}
static int ProcessManagementRecord(int type, FCGX_Stream *stream)
{
    FCGX_Stream_Data *data = (FCGX_Stream_Data *)stream->data;
    ParamsPtr paramsPtr = NewParams(3);
    char **pPtr;
    char response[64];
    char *responseP = &response[8];
    char *name, value = '\0';
    int len, paddedLen;
    if(type == 9) {
        ReadParams(paramsPtr, stream);
        if((FCGX_GetError(stream) != 0) || (data->contentLen != 0)) {
            FreeParams(&paramsPtr);
            return -3;
        }
        for (pPtr = paramsPtr->vec; pPtr < paramsPtr->cur; pPtr++) {
            name = *pPtr;
            *(strchr(name, '=')) = '\0';
            if(strcmp(name, "FCGI_MAX_CONNS") == 0) {
                value = '1';
            } else if(strcmp(name, "FCGI_MAX_REQS") == 0) {
                value = '1';
            } else if(strcmp(name, "FCGI_MPXS_CONNS") == 0) {
                value = '0';
            } else {
                name = NULL;
            }
            if(name != NULL) {
                len = strlen(name);
                responseP += len + 3;
	    }
        }
        len = responseP - &response[8];
        paddedLen = AlignInt8(len);
        *((FCGI_Header *) response) = MakeHeader(10, 0, len, paddedLen - len);
        FreeParams(&paramsPtr);
    } else {
        paddedLen = len = sizeof(FCGI_UnknownTypeBody);
        ((FCGI_UnknownTypeRecord *) response)->header = MakeHeader(11, 0, len, 0);
        ((FCGI_UnknownTypeRecord *) response)->body = MakeUnknownTypeBody(type);
    }
    if (write_it_all(data->reqDataPtr->ipcFd, response, 8 + paddedLen) < 0) {
        SetError(stream, errno);
        return -1;
    }
    return 3;
}
static int ProcessBeginRecord(int requestId, FCGX_Stream *stream)
{
    FCGX_Stream_Data *data = (FCGX_Stream_Data *)stream->data;
    FCGI_BeginRequestBody body;
    if(requestId == 0 || data->contentLen != sizeof(body)) {
        return -3;
    }
    if(data->reqDataPtr->isBeginProcessed) {
        FCGI_EndRequestRecord endRequestRecord;
        endRequestRecord.header = MakeHeader(3, requestId, sizeof(endRequestRecord.body), 0);
        endRequestRecord.body = MakeEndRequestBody(0, 1);
        if (write_it_all(data->reqDataPtr->ipcFd, (char *)&endRequestRecord, sizeof(endRequestRecord)) < 0) {
            SetError(stream, errno);
            return -1;
        }
        return 1;
    }
    data->reqDataPtr->requestId = requestId;
    if(FCGX_GetStr((char *) &body, sizeof(body), stream) != sizeof(body)) {
        return -3;
    }
    data->reqDataPtr->keepConnection = (body.flags & 1);
    data->reqDataPtr->role = (body.roleB1 << 8) + body.roleB0;
    data->reqDataPtr->isBeginProcessed = TRUE;
    return 2;
}
static int ProcessHeader(FCGI_Header header, FCGX_Stream *stream)
{
    FCGX_Stream_Data *data = (FCGX_Stream_Data *)stream->data;
    int requestId;
    if(header.version != 1) {
        return -2;
    }
    requestId = (header.requestIdB1 << 8) + header.requestIdB0;
    data->contentLen = (header.contentLengthB1 << 8) + header.contentLengthB0;
    data->paddingLen = header.paddingLength;
    if(header.type == 1) {
        return ProcessBeginRecord(requestId, stream);
    }
    if(requestId  == 0) {
        return ProcessManagementRecord(header.type, stream);
    }
    if(requestId != data->reqDataPtr->requestId) {
        return 1;
    }
    if(header.type != data->type) {
        return -3;
    }
    return 0;
}
static void FillBuffProc(FCGX_Stream *stream)
{
    FCGX_Stream_Data *data = (FCGX_Stream_Data *)stream->data;
    FCGI_Header header;
    int headerLen = 0;
    int status, count;
    for (;;) {
        if(stream->rdNext == data->buffStop) {
            count = read(data->reqDataPtr->ipcFd, (char *)data->buff, data->bufflen);
            if(count <= 0) {
                SetError(stream, (count == 0 ? -3 : errno));
                return;
            }
            stream->rdNext = data->buff;
            data->buffStop = data->buff + count;
	}
        if(data->contentLen > 0) {
            count = min(data->contentLen, data->buffStop - stream->rdNext);
            data->contentLen -= count;
            if(!data->skip) {
                stream->wrNext = stream->stop = stream->rdNext + count;
                return;
	    } else {
                stream->rdNext += count;
                if(data->contentLen > 0) {
                    continue;
	        } else {
                    data->skip = FALSE;
	        }
	    }
	}
        if(data->paddingLen > 0) {
            count = min(data->paddingLen, data->buffStop - stream->rdNext);
            data->paddingLen -= count;
            stream->rdNext += count;
            if(data->paddingLen > 0) {
                continue;
	    }
	}
        if(data->eorStop) {
            stream->stop = stream->rdNext;
            stream->isClosed = TRUE;
            return;
        }
        count = min((int)sizeof(header) - headerLen, data->buffStop - stream->rdNext);
        memcpy(((char *)(&header)) + headerLen, stream->rdNext, count);
        headerLen += count;
        stream->rdNext += count;
        if(headerLen < sizeof(header)) {
            continue;
	};
        headerLen = 0;
        data->eorStop = TRUE;
        stream->stop = stream->rdNext;
        status = ProcessHeader(header, stream);
        data->eorStop = FALSE;
        stream->isClosed = FALSE;
        switch(status) {
            case 0:
                if(data->contentLen == 0) {
                    stream->wrNext = stream->stop = stream->rdNext;
                    stream->isClosed = TRUE;
                    return;
	        }
                break;
	    case 1:
                data->skip = TRUE;
                break;
            case 2:
                return;
                break;
            case 3:
                break;
            default:
                assert(status < 0);
                SetError(stream, status);
                return;
                break;
	}
    }
}
static FCGX_Stream *NewStream(FCGX_Request *reqDataPtr, int bufflen, int isReader, int streamType)
{
    FCGX_Stream *stream = (FCGX_Stream *)Malloc(sizeof(FCGX_Stream));
    FCGX_Stream_Data *data = (FCGX_Stream_Data *)Malloc(sizeof(FCGX_Stream_Data));
    data->reqDataPtr = reqDataPtr;
    bufflen = AlignInt8(min(max(bufflen, 32), 0xffff + 1));
    data->bufflen = bufflen;
    data->mBuff = (unsigned char *)Malloc(bufflen);
    data->buff = AlignPtr8(data->mBuff);
    if(data->buff != data->mBuff) {
        data->bufflen -= 8;
    }
    if(isReader) {
        data->buffStop = data->buff;
    } else {
        data->buffStop = data->buff + data->bufflen;
    }
    data->type = streamType;
    data->eorStop = FALSE;
    data->skip = FALSE;
    data->contentLen = 0;
    data->paddingLen = 0;
    data->isAnythingWritten = FALSE;
    data->rawWrite = FALSE;
    stream->data = data;
    stream->isReader = isReader;
    stream->isClosed = FALSE;
    stream->wasFCloseCalled = FALSE;
    stream->FCGI_errno = 0;
    if(isReader) {
        stream->fillBuffProc = FillBuffProc;
        stream->emptyBuffProc = NULL;
        stream->rdNext = data->buff;
        stream->stop = stream->rdNext;
        stream->stopUnget = data->buff;
        stream->wrNext = stream->stop;
    } else {
        stream->fillBuffProc = NULL;
        stream->emptyBuffProc = EmptyBuffProc;
        stream->wrNext = data->buff + sizeof(FCGI_Header);
        stream->stop = data->buffStop;
        stream->stopUnget = NULL;
        stream->rdNext = stream->stop;
    }
    return stream;
}
void FCGX_FreeStream(FCGX_Stream **streamPtr)
{
    FCGX_Stream *stream = *streamPtr;
    FCGX_Stream_Data *data;
    if(stream == NULL) {
        return;
    }
    data = (FCGX_Stream_Data *)stream->data;
    data->reqDataPtr = NULL;
    free(data->mBuff);
    free(data);
    free(stream);
    *streamPtr = NULL;
}
static FCGX_Stream *SetReaderType(FCGX_Stream *stream, int streamType)
{
    FCGX_Stream_Data *data = (FCGX_Stream_Data *)stream->data;
    assert(stream->isReader);
    data->type = streamType;
    data->eorStop = FALSE;
    data->skip = FALSE;
    data->contentLen = 0;
    data->paddingLen = 0;
    stream->wrNext = stream->stop = stream->rdNext;
    stream->isClosed = FALSE;
    return stream;
}
static FCGX_Stream *NewReader(FCGX_Request *reqDataPtr, int bufflen, int streamType)
{
    return NewStream(reqDataPtr, bufflen, TRUE, streamType);
}
static FCGX_Stream *NewWriter(FCGX_Request *reqDataPtr, int bufflen, int streamType)
{
    return NewStream(reqDataPtr, bufflen, FALSE, streamType);
}
void FCGX_Finish_R(FCGX_Request *reqDataPtr)
{
    int close;
    if (reqDataPtr == NULL) {
        return;
    }
    close = !reqDataPtr->keepConnection;
    if (reqDataPtr->in) {
        close |= FCGX_FClose(reqDataPtr->err);
        close |= FCGX_FClose(reqDataPtr->out);
	close |= FCGX_GetError(reqDataPtr->in);
    }
    FCGX_Free(reqDataPtr, close);
}
void FCGX_Free(FCGX_Request * request, int close)
{
    if (request == NULL) 
        return;
    FCGX_FreeStream(&request->in);
    FCGX_FreeStream(&request->out);
    FCGX_FreeStream(&request->err);
    FreeParams(&request->paramsPtr);
    if (close) {
        OS_IpcClose(request->ipcFd, ! request->detached);
        request->ipcFd = -1;
        request->detached = 0;
    }
}
int FCGX_InitRequest(FCGX_Request *request, int sock, int flags)
{
    memset(request, 0, sizeof(FCGX_Request));
    request->listen_sock = sock;
    request->flags = flags;
    request->ipcFd = -1;
    return 0;
}
int FCGX_Init(void)
{
    char *p;
    if (libInitialized) {
        return 0;
    }
    FCGX_InitRequest(&the_request, 0, 0);
    if (OS_LibInit(NULL) == -1) {
        return errno ? errno : -9997;
    }
    p = getenv("FCGI_WEB_SERVER_ADDRS");
    webServerAddressList = p ? StringCopy(p) : NULL;
    libInitialized = 1;
    return 0;
}
int FCGX_Accept_R(FCGX_Request *reqDataPtr)
{
    if (!libInitialized) {
        return -9998;
    }
    FCGX_Finish_R(reqDataPtr);
    for (;;) {
        if (reqDataPtr->ipcFd < 0) {
            int fail_on_intr = reqDataPtr->flags & 1;
            reqDataPtr->ipcFd = OS_Accept(reqDataPtr->listen_sock, fail_on_intr, webServerAddressList);
            if (reqDataPtr->ipcFd < 0) {
                return (errno > 0) ? (0 - errno) : -9999;
            }
        }
        reqDataPtr->isBeginProcessed = FALSE;
        reqDataPtr->in = NewReader(reqDataPtr, 8192, 0);
        FillBuffProc(reqDataPtr->in);
        if(!reqDataPtr->isBeginProcessed) {
            goto TryAgain;
        }
        {
            char *roleStr;
            switch(reqDataPtr->role) {
                case 1:
                    roleStr = "FCGI_ROLE=RESPONDER";
                    break;
                case 2:
                    roleStr = "FCGI_ROLE=AUTHORIZER";
                    break;
                case 3:
                    roleStr = "FCGI_ROLE=FILTER";
                    break;
                default:
                    goto TryAgain;
            }
            reqDataPtr->paramsPtr = NewParams(30);
            PutParam(reqDataPtr->paramsPtr, StringCopy(roleStr));
        }
        SetReaderType(reqDataPtr->in, 4);
        if(ReadParams(reqDataPtr->paramsPtr, reqDataPtr->in) >= 0) {
            break;
        }
TryAgain:
        FCGX_Free(reqDataPtr, 1);
    }
    SetReaderType(reqDataPtr->in, 5);
    reqDataPtr->out = NewWriter(reqDataPtr, 8192, 6);
    reqDataPtr->err = NewWriter(reqDataPtr, 512, 7);
    reqDataPtr->nWriters = 2;
    reqDataPtr->envp = reqDataPtr->paramsPtr->vec;
    return 0;
}