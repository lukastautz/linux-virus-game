// Provides support for FastCGI via C++ iostreams.
// This work is based on routines written by George Feinberg. They
// have been mostly re-written and extensively changed by
// Michael Richards.
//
// Rewritten again with bug fixes and numerous enhancements by
// Michael Shell.
// 
// And rewritten again by Rob Saccoccio. 
//
// Copyright (c) 2000 Tux the Linux Penguin
// Copyright (c) 2001 Rob Saccoccio and Chelsea Networks
//
// You are free to use this software without charge or royalty
// as long as this notice is not removed or altered, and recognition
// is given to the author(s)
//
// This code is offered as-is without any warranty either expressed or
// implied; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  If it breaks, you get to keep 
// both halves.
#ifndef FCGIO_H
#define FCGIO_H
#include <iostream>
#include "fcgiapp.h"
#ifndef DLLAPI
#define DLLAPI
#endif
#if ! HAVE_STREAMBUF_CHAR_TYPE
typedef char char_type;
#endif
class DLLAPI fcgi_streambuf : public std::streambuf
{
public:
    fcgi_streambuf(FCGX_Stream * fcgx, char * buf, int len);
    fcgi_streambuf(char_type * buf, std::streamsize len);
    fcgi_streambuf(FCGX_Stream * fcgx = 0);
    ~fcgi_streambuf(void);
    int attach(FCGX_Stream * fcgx);

protected:
    virtual int overflow(int);
    virtual int sync();
    virtual int uflow();
    virtual int underflow();
    virtual std::streambuf * setbuf(char_type * buf, std::streamsize len);
    virtual std::streamsize xsgetn(char_type * s, std::streamsize n);
    virtual std::streamsize xsputn(const char_type * s, std::streamsize n);

private:
    FCGX_Stream * fcgx;
    char_type * buf;
    std::streamsize bufsize;
    void init(FCGX_Stream * fcgx, char_type * buf, std::streamsize bufsize);
    void reset(void);
};
class DLLAPI fcgi_istream : public std::istream
{
public:
    fcgi_istream(FCGX_Stream * fcgx = 0);
    ~fcgi_istream(void) {}
    virtual void attach(FCGX_Stream * fcgx);

private:
    fcgi_streambuf fcgi_strmbuf;
};
class DLLAPI fcgi_ostream : public std::ostream
{
public:
    fcgi_ostream(FCGX_Stream * fcgx = 0);
    ~fcgi_ostream(void) {}
    virtual void attach(FCGX_Stream *fcgx);

private:
    fcgi_streambuf fcgi_strmbuf;
};
#endif