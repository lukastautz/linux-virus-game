/* Definitions for FastCGI application server programs
 * Copyright (c) 1996 Open Market, Inc.
 * See the file "LICENSE.TERMS" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 */
#ifndef _FCGIAPP_H
#define _FCGIAPP_H
#ifndef TCL_LIBRARY
#include <stdarg.h>
#else
#include <varargs.h>
#endif
#ifndef DLLAPI
#define DLLAPI
#endif
#define FCGX_UNSUPPORTED_VERSION -2
#define FCGX_PROTOCOL_ERROR -3
#define FCGX_PARAMS_ERROR -4
#define FCGX_CALL_SEQ_ERROR -5
typedef struct FCGX_Stream {
    unsigned char *rdNext;
    unsigned char *wrNext;
    unsigned char *stop;
    unsigned char *stopUnget;
    int isReader;
    int isClosed;
    int wasFCloseCalled;
    int FCGI_errno;
    void (*fillBuffProc) (struct FCGX_Stream *stream);
    void (*emptyBuffProc) (struct FCGX_Stream *stream, int doClose);
    void *data;
} FCGX_Stream;
typedef char **FCGX_ParamArray;
#define FCGI_FAIL_ACCEPT_ON_INTR	1
typedef struct FCGX_Request {
    int requestId;
    int role;
    FCGX_Stream *in;
    FCGX_Stream *out;
    FCGX_Stream *err;
    char **envp;
    struct Params *paramsPtr;
    int ipcFd;
    int isBeginProcessed;
    int keepConnection;
    int appStatus;
    int nWriters;
    int flags;
    int listen_sock;
    int detached;
} FCGX_Request;
DLLAPI int FCGX_IsCGI(void);
DLLAPI int FCGX_Init(void);
DLLAPI int FCGX_OpenSocket(const char *path, int backlog);
DLLAPI int FCGX_InitRequest(FCGX_Request *request, int sock, int flags);
DLLAPI int FCGX_Accept_r(FCGX_Request *request);
DLLAPI void FCGX_Finish_r(FCGX_Request *request);
DLLAPI void FCGX_Free(FCGX_Request * request, int close);
DLLAPI int FCGX_Accept(
        FCGX_Stream **in,
        FCGX_Stream **out,
        FCGX_Stream **err,
        FCGX_ParamArray *envp);
DLLAPI void FCGX_Finish(void);
DLLAPI int FCGX_StartFilterData(FCGX_Stream *stream);
DLLAPI void FCGX_SetExitStatus(int status, FCGX_Stream *stream);
DLLAPI char *FCGX_GetParam(const char *name, FCGX_ParamArray envp);
DLLAPI int FCGX_GetChar(FCGX_Stream *stream);
DLLAPI int FCGX_UnGetChar(int c, FCGX_Stream *stream);
DLLAPI int FCGX_GetStr(char *str, int n, FCGX_Stream *stream);
DLLAPI char *FCGX_GetLine(char *str, int n, FCGX_Stream *stream);
DLLAPI  int FCGX_HasSeenEOF(FCGX_Stream *stream);
DLLAPI int FCGX_PutChar(int c, FCGX_Stream *stream);
DLLAPI int FCGX_PutStr(const char *str, int n, FCGX_Stream *stream);
DLLAPI int FCGX_PutS(const char *str, FCGX_Stream *stream);
DLLAPI int FCGX_FPrintF(FCGX_Stream *stream, const char *format, ...);
DLLAPI int FCGX_VFPrintF(FCGX_Stream *stream, const char *format, va_list arg);
DLLAPI int FCGX_FFlush(FCGX_Stream *stream);
DLLAPI int FCGX_FClose(FCGX_Stream *stream);
DLLAPI int FCGX_GetError(FCGX_Stream *stream);
DLLAPI void FCGX_ClearError(FCGX_Stream *stream);
DLLAPI FCGX_Stream *FCGX_CreateWriter(
        int socket,
        int requestId,
        int bufflen,
        int streamType);
DLLAPI void FCGX_FreeStream(FCGX_Stream **stream);
DLLAPI void FCGX_ShutdownPending(void);
DLLAPI int FCGX_Attach(FCGX_Request * r);
DLLAPI int FCGX_Detach(FCGX_Request * r);
#endif