#include <pthread.h>
#include "include/fcgiapp.c"
#include "json.c"
//#include <stdio.h>
#define THREAD_COUNT 100
#define string char *

/* A function to place the "content" of the thread. */
void *runThread(void *id)
{
    
    FCGX_Request request;
    FCGX_InitRequest(&request, 0, 0);
    for (;;)
    {
        //static pthread_mutex_t accept_mutex = PTHREAD_MUTEX_INITIALIZER;
        //pthread_mutex_lock(&accept_mutex);
		FCGX_Accept_R(&request);
        //pthread_mutex_unlock(&accept_mutex);
        //server_name = FCGX_GetParam("QUERY_STRING", request.envp);
        Print(request.out,
            "Content-Type: text/html\n\n"
            "<title>FastCGI Hello! (multi-threaded C, fcgiapp library)</title>"
            "<h1>FastCGI Hello! (multi-threaded C, fcgiapp library)</h1>"
            "This is a hello world program (multithreaded!)");
        char *uri = FCGX_GetParam("REQUEST_URI", request.envp);
        Print(request.out, "<br>Url: ");
        Print(request.out, uri);
        Print(request.out, "<br>");
        if (atoi(FCGX_GetParam("UPLOAD", request.envp)) == 0)
        {
            Print(request.out,"No upload");
            string jsonData = "{\"mykey\":\"grfgvdg reges\"}";
            json_token_t tokens[128];
            json_t lwjson;
            json_init(&lwjson, tokens, JSON_ARRAYSIZE(tokens));
            if (json_parse(&lwjson, jsonData) == jsonOK) {
                /*const json_token_t* t;
                if ((t = json_find(&lwjson, "mykey")) != NULL)
                {
                    if (t->type == JSON_TYPE_STRING)
                    {
                        Print(request.out,"JSON_TYPE_STRING");
                    }
                    else
                    {
                        Print(request.out,"JSON_TYPE_IS_UNKNOWN");
                    }
                }
                else
                {
                    Print(request.out,"(t = json_find(&lwjson, \"mykey\")) == NULL");
                }*/
                Print(request.out,json_get_string(&lwjson,"mykey"));
                
            }
            else
            {
                Print(request.out, "ERROR");
                Print(request.out, "<br>");
                Print(request.out, jsonData);
            }
            json_free(&lwjson);
        }
        else
        {
            char *ilen = FCGX_GetParam("REQUEST_BODY_FILE", request.envp);
            Print(request.out,"The temp file is: ");
            Print(request.out,ilen);
            Print(request.out,"\n\n");
        }
        /*
        char *bufp = malloc(ilen);
        FCGX_GetStr(bufp, ilen, request.in);

        FILE *file = fopen("cnt.txt", "w");
        fputs(bufp, file);
        fclose(file);*/

        //free(bufp);
        //char bufp[1024*1024*1024];
        //char l;
        
       // char *bufp;

     
        //free(bufp);
        FCGX_Finish_R(&request);
    }
    return NULL;
}

/* The main program */
int main()
{
    int id;
    pthread_t threads[THREAD_COUNT];
    FCGX_Init();
    for (id = 1; id < THREAD_COUNT; id++)
	{
		pthread_create(&threads[id], NULL, runThread, NULL);
	}
    runThread(0);
    return 0;
}