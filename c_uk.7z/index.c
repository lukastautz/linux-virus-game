#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "www_lib.c"


int main ()
{
    wwwLibInit("text/html");
    //FILE* f = file_open("test.txt", FILE_READ_WRITE);
    //file_append(f, "dies ist ein test\n");
    //file_append(f, "\tdies ist line 2");
    //echo(file_read(f));
    //file_append(f,"\ntextgrg\nletzte zeile");
    //echo(DOUBLE_EOL);
    //echo(file_read(f));
    //file_close(f);
    // printf ("<!DOCTYPE html>\n<html>\n\t<head>\n\t\t<title>It works!</title>\n\t</head>\n\t<body>\n\t\t<h1>It works!</h1>\n\t\tThis site is generated with C(2)!\n\t</body>\n</html>");
    // printf(LANGUAGE_NAME);
    /*if (!strcmp(getenv("REQUEST_METHOD"), "POST")) {
        int ilen = atoi(getenv("CONTENT_LENGTH"));
        char *bufp = malloc(ilen);
        fread(bufp, ilen, 1, stdin);
        printf("The POST data is<P>%s\n", bufp);
        free(bufp);
    }
    else
    {
        printf(getenv("REQUEST_METHOD"));
    }*/
    //echo("test");
   // echo(file_get_contents("test.txt"));
   // file_append("test.txt", "\nline LAST");
  //  echo(file_get_contents("test.txt"));
  //  file_put_contents("test.txt", "\nline LAST and First");
  //  echo(file_get_contents("test.txt"));
  //  long i = 9223372036854775807;
  //  echo(long2str(i));
  printf("%s", double2str(15434.345));
    return 0;
}
