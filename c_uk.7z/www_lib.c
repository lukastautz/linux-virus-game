#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
/*
WWW_LIB <www_lib.c>
Copyright (C) 2022 Lukas Tautz

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

You can use siteFactoryCSS for free in your projects, you can also modify the siteFactoryCSS files BUT YOU ARE NOT ALLOWED TO DELETE THIS COMMENT!
*/
#ifndef WWW_LIB
#define WWW_LIB                 "1.0"
#define WWW_LIB_VERSION         "1.0 (2022-07-05)"

// Definitions:
#define WWW_LIB_FILE_FUNCTIONS  1
#define WWW_LIB_LOG_FUNCTIONS   1
#define EOL                     "\n"
#define DOUBLE_EOL              "\n\n"
#define TAB                     "\t"
#define DOUBLE_TAB              "\t\t"
#define LOG_FILE                "/var/www_lib_log.txt"


short contentTypeSent = 0;
void wwwLibInit(char *contentType)
{
    printf("Content-Type: ");
    printf(contentType);
    printf(DOUBLE_EOL);
}
int str2short(char *string)
{
    short returnV = atoi(string);
    return returnV;
}
int str2int(char *string)
{
    return atoi(string);
}
double str2double(char *string)
{
    return atof(string);
}
long str2long(char *string)
{
    return atol(string);
}
char* int2str(int intV)
{
    char* tmp = (char*)malloc(sizeof(int));
    sprintf(tmp, "%ld", intV);
    char* buffer = (char*)malloc(strlen(tmp));
    buffer = tmp;
    return buffer;
}
char* short2str(short intV)
{
    char* tmp = (char*)malloc(sizeof(short));
    sprintf(tmp, "%i", intV);
    char* buffer = (char*)malloc(strlen(tmp));
    buffer = tmp;
    return buffer;
}
char* double2str(double intV)
{
    char* tmp = (char*)malloc(sizeof(double));
    sprintf(tmp, "%f", intV);
    while (tmp[strlen(tmp)-1] == '0')
    {
        tmp[strlen(tmp)-1] = '\0';
    }
    char* buffer = (char*)malloc(strlen(tmp));
    buffer = tmp;
    return buffer;
}
char* long2str(long intV)
{
    char* tmp = (char*)malloc(sizeof(long));
    sprintf(tmp, "%ld", intV);
    char* buffer = (char*)malloc(strlen(tmp));
    buffer = tmp;
    return buffer;
}
void echo(char *string)
{
    printf(string);
}

// Log functions:
#if WWW_LIB_LOG_FUNCTIONS == 1
void wwwLibLog(char *text)
{
    FILE *file = fopen(LOG_FILE, "a");
    fputs("LOG: ", file);
    fputs(text, file);
    fputs("\n", file);
    fclose(file);
}
void wwwLibError(char *text)
{
    FILE *file = fopen(LOG_FILE, "a");
    fputs("ERROR: ", file);
    fputs(text, file);
    fputs("\n", file);
    fclose(file);
}
void wwwLibWarning(char *text)
{
    FILE *file = fopen(LOG_FILE, "a");
    fputs("ERROR: ", file);
    fputs(text, file);
    fputs("\n", file);
    fclose(file);
}
#endif

// File functions:
#if WWW_LIB_FILE_FUNCTIONS == 1
char* fileGetContents(char *name)
{
    FILE *file = fopen(name, "r");
    fseek(file, 0L, SEEK_END);
    long length = ftell(file);
    rewind(file);
    char* buffer = (char*)malloc((length + 1));
    fread(buffer, 1, length, file);
    fclose(file);
    return buffer;
}
void filePutContents(char *name, char *content)
{
    FILE *file = fopen(name, "w");
    fputs(content, file);
    fclose(file);
}
void fileAppend(char *name, char *content)
{
    FILE *file = fopen(name, "a");
    fputs(content, file);
    fclose(file);
}
#else

#endif
#endif
// WWW_LIB End